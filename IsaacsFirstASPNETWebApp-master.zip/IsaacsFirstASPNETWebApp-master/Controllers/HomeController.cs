﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using IsaacsFirstASPNETWebApp.Models;

namespace IsaacsFirstASPNETWebApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        // Handle the Get Request
        [HttpGet("GradeCalc")]
        public IActionResult GradeCalc ()
        {
            return View();
        }

        // Handle the Post Request
        [HttpPost("GradeCalc")]
        public IActionResult GradeCalc (GradeCalcModel model)
        {
            return View();
        }
    }
}
